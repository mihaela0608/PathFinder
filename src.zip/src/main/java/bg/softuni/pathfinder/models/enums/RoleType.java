package bg.softuni.pathfinder.models.enums;

public enum RoleType {
    USER, MODERATOR, ADMIN
}
