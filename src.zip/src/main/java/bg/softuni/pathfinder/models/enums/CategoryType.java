package bg.softuni.pathfinder.models.enums;

public enum CategoryType {
    PEDESTRIAN, BICYCLE, MOTORCYCLE, CAR
}
