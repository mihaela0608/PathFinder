package bg.softuni.pathfinder.models.enums;

public enum Level {
    BEGINNER, INTERMEDIATE, ADVANCED
}
