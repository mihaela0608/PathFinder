package bg.softuni.pathfinder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PathFinderApplicationTests {

    @Test
    void contextLoads() {
    }

}
